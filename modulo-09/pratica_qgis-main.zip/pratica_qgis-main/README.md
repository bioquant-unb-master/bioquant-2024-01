# pratica_qgis
Repositório criado para a prática de geoprocessamento do modulo 7 do curso de biologia quantitativa de 2020
